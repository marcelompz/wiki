// e2e/landed-cost-multimoneda.spec.ts

import { test, expect } from '@playwright/test';
import { loginAsAdmin } from '../helpers/auth';
import { TENANT_PROVECCHIO } from '../helpers/tenants';

test('landed cost con factura de flete en USD y aduana en PYG se prorratea correctamente', async ({ page }) => {
  await loginAsAdmin(page, TENANT_PROVECCHIO);
  await page.goto('/admin/inventory/receipts/receipt-test-1/landed-cost');

  await page.click('text=Agregar línea de costo');
  await page.selectOption('[name="tipo"]', 'FLETE_INTERNACIONAL');
  await page.selectOption('[name="monedaOriginal"]', 'USD');
  await page.fill('[name="montoOriginal"]', '100');
  await page.fill('[name="fechaFactura"]', '2026-08-01');
  await page.click('text=Guardar línea');

  // Si no hay cotización histórica para esa fecha, debe aparecer el form de carga manual
  const modalManual = page.locator('text=Cargar cotización manual');
  if (await modalManual.isVisible()) {
    await page.fill('[name="cotizacion"]', '7500');
    await page.click('text=Confirmar cotización');
  }

  await expect(page.locator('[data-testid="linea-costo-usd"]')).toContainText('USD 100.00');
  await expect(page.locator('[data-testid="linea-costo-usd-convertido"]')).toContainText('PYG 750.000');

  await page.click('text=Prorratear costos');
  await expect(page.locator('[data-testid="resultado-prorrateo"]')).toBeVisible();
});
