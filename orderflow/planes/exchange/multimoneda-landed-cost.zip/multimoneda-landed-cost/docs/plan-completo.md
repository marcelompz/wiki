# Plan completo — Historial de Cotizaciones y Landed Cost Multimoneda (FEAT-082)

## Contexto

OrderFlow ya tiene multimoneda funcionando en producción (v1.5.0):
`CurrencyService` con caché de 30 min + API externa (dolarapi) + fallback
estático, y `Order` que congela `currency`/`exchangeRate`/`totalAmountBase`
al confirmar. Ese diseño alcanza para el POS (necesita la cotización de
"ahora"), pero no para landed cost, que es retroactivo por naturaleza: se
cargan facturas de flete/aduana de semanas atrás y hace falta la cotización
vigente en esa fecha, no la de hoy. Este plan cierra ese hueco extendiendo
la infraestructura existente en vez de reconstruirla.

## Etapa 0 — Persistencia de cotizaciones (base transversal)

- Modelo `ExchangeRateHistory`: tenantId, monedaOrigen, monedaDestino,
  cotización, fechaEfectiva, fuente (API/MANUAL). Historizado — nunca se
  pisa un registro.
- `CurrencyService.resolveRate(tenantId, from, to, fecha?)`: si la fecha es
  hoy/ausente, usa el flujo actual y hace write-through al historial; si es
  pasada, consulta el historial por fecha. Devuelve `null` explícito si no
  hay dato — nunca inventa un valor.
- Endpoint `POST /exchange-rates/manual` para tapar huecos cuando no hay
  cotización histórica disponible.

## Etapa 1 — `CostAdjustment` multimoneda (landed cost)

- Extensión con `montoOriginal`, `monedaOriginal`, `exchangeRateId`,
  `montoConvertido`.
- Al cargar cada línea, se resuelve la cotización por la fecha de la
  factura. Si no hay dato, se dispara `CotizacionNoDisponibleException` y
  el frontend ofrece carga manual.
- La distribución por promedio ponderado se prorratea siempre sobre
  `montoConvertido` (moneda de costeo del tenant), nunca sobre el monto
  original — así un mismo `receiptId` con líneas en distintas monedas
  queda comparable.

## Etapa 2 — Compras en general

- Mismo patrón de 4 campos en `PurchaseInvoice`.
- Lógica de conversión subida a un helper compartido
  (`resolverConversion()`) para no duplicarla entre landed cost y compras.
- Componente de UI único (`CurrencyAmountInput`) reutilizado en ambos
  formularios.

## Etapa 3 — QA / validación

- Unit tests de `resolveRate` (actual, histórico con dato, histórico sin
  dato, aislamiento por tenant).
- Unit tests de distribución de landed cost con facturas en 2+ monedas.
- E2E Playwright del flujo completo (factura en USD + aduana en PYG →
  prorrateo correcto).
- `./scripts/init.sh` se corre solo con confirmación explícita del usuario,
  según protocolo de AGENTS.md.

## Directrices agregadas a AGENTS.md

Ver `docs/AGENTS-multimoneda-seccion.md` — 6 reglas transversales para que
cualquier feature futura que toque montos multimoneda siga el mismo patrón:
fuente única de cotizaciones, nunca persistir solo el monto convertido,
retroactivo contra historial no contra caché, carga manual explícita sin
valores por defecto silenciosos, conversión centralizada en un helper
compartido, y UI compartida.

## Etapa 4 — Cierre (pendiente de ejecución real)

- Agregar la entrada `FEAT-082` a `featurelist.json` (ver
  `docs/featurelist-FEAT-082.json` — confirmado como próximo ID libre:
  FEAT-080 y FEAT-081 ya estaban tomados en el `featurelist.json` real).
- Protocolo de 3 roles: Planificador (este documento) → Implementador
  (aplica los snippets) → Revisor (corre `init.sh`, sincroniza versión en
  VERSION/package.json/README/ROADMAP/CHANGELOG/docs/02-architecture.md/
  manifiestos/Wiki, y tag de versión).
