## Manejo de multimoneda (transversal a todos los módulos)

Estas reglas aplican a cualquier feature que registre o procese montos en una
moneda distinta a la moneda base/de costeo del tenant (landed cost, compras,
POS, facturación, etc.):

1. **Fuente única de cotizaciones**: toda resolución de tipo de cambio pasa
   exclusivamente por `CurrencyService.resolveRate()`. Prohibido calcular,
   cachear o hardcodear tipos de cambio en otro service, controller o
   componente de frontend.

2. **Nunca persistir solo el monto convertido**: cualquier entidad que
   registre un monto en moneda distinta a la de costeo del tenant debe
   guardar los cuatro campos: `montoOriginal`, `monedaOriginal`,
   `exchangeRateId` (referencia a `ExchangeRateHistory`, no un decimal
   suelto) y `montoConvertido`. El monto convertido se calcula; el original
   y la cotización usada son el dato de verdad.

3. **Retroactivo consulta historial, no caché**: para operaciones con fecha
   pasada (factura de flete de hace semanas, aduanas del mes anterior),
   `resolveRate(tenantId, origen, destino, fecha)` resuelve contra
   `ExchangeRateHistory` filtrando por fecha. El caché en memoria (TTL 30
   min) solo es válido para "ahora" — nunca se usa para resolver una fecha
   pasada.

4. **Sin cotización histórica → carga manual explícita, nunca un valor por
   defecto**: si `resolveRate` devuelve `null`, el flujo debe ofrecer carga
   manual de la cotización (vía `POST /exchange-rates/manual`). Esa carga
   queda historizada con `fuente=MANUAL` y el usuario que la cargó.
   Prohibido asumir silenciosamente la cotización más reciente disponible
   como si fuera la de la fecha solicitada.

5. **Conversión centralizada, no duplicada por módulo**: la lógica de
   "resolver cotización + convertir monto" vive en un único helper
   compartido (`resolverConversion()` en
   `common/services/currency-conversion.helper.ts`). Cualquier módulo nuevo
   que necesite convertir montos (compras, landed cost, y los que vengan
   después) lo reutiliza — no se reimplementa el cálculo en el service del
   módulo.

6. **UI compartida**: el componente de captura de monto en moneda
   extranjera (selector de moneda + fecha + cotización resuelta o editable)
   es uno solo y se reutiliza entre formularios — no se duplica su lógica
   por pantalla.
