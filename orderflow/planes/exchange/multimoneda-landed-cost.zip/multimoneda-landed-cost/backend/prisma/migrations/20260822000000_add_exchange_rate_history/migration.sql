CREATE TYPE "ExchangeRateSource" AS ENUM ('API', 'MANUAL');

CREATE TABLE "ExchangeRateHistory" (
  "id" TEXT NOT NULL,
  "tenantId" TEXT NOT NULL,
  "monedaOrigen" TEXT NOT NULL,
  "monedaDestino" TEXT NOT NULL,
  "cotizacion" DECIMAL(18,6) NOT NULL,
  "fechaEfectiva" TIMESTAMP(3) NOT NULL,
  "fuente" "ExchangeRateSource" NOT NULL,
  "cargadoPor" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "ExchangeRateHistory_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "ExchangeRateHistory_tenantId_monedaOrigen_monedaDestino_fechaEfectiva_idx"
  ON "ExchangeRateHistory"("tenantId", "monedaOrigen", "monedaDestino", "fechaEfectiva");

ALTER TABLE "ExchangeRateHistory" ADD CONSTRAINT "ExchangeRateHistory_tenantId_fkey"
  FOREIGN KEY ("tenantId") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Extensión de CostAdjustment (landed cost) para multimoneda
ALTER TABLE "CostAdjustment"
  ADD COLUMN "montoOriginal" DECIMAL(18,6) NOT NULL,
  ADD COLUMN "monedaOriginal" TEXT NOT NULL,
  ADD COLUMN "exchangeRateId" TEXT,
  ADD COLUMN "montoConvertido" DECIMAL(18,6) NOT NULL;

ALTER TABLE "CostAdjustment" ADD CONSTRAINT "CostAdjustment_exchangeRateId_fkey"
  FOREIGN KEY ("exchangeRateId") REFERENCES "ExchangeRateHistory"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Extensión de PurchaseInvoice para multimoneda
ALTER TABLE "PurchaseInvoice"
  ADD COLUMN "montoOriginal" DECIMAL(18,6) NOT NULL,
  ADD COLUMN "monedaOriginal" TEXT NOT NULL,
  ADD COLUMN "exchangeRateId" TEXT,
  ADD COLUMN "montoConvertido" DECIMAL(18,6) NOT NULL;

ALTER TABLE "PurchaseInvoice" ADD CONSTRAINT "PurchaseInvoice_exchangeRateId_fkey"
  FOREIGN KEY ("exchangeRateId") REFERENCES "ExchangeRateHistory"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- NOTA: si CostAdjustment / PurchaseInvoice ya tienen filas existentes,
-- estas columnas NOT NULL requieren un valor por defecto o un paso previo
-- de backfill antes de aplicar en un entorno con datos. En OmniFlow (aún
-- no productivo) puede aplicarse directo.
