// backend/src/purchasing/services/purchase-invoice.service.ts
//
// Agregar/reemplazar el método registrarFactura() de la clase existente
// con esta versión, que reutiliza el mismo helper que landed cost.

import { RegistrarFacturaDto } from '../dto/registrar-factura.dto';

export class PurchaseInvoiceServiceAdditions {
  async registrarFactura(tenantId: string, dto: RegistrarFacturaDto) {
    const tenant = await this.tenantPrisma(tenantId).tenant.findUniqueOrThrow({
      where: { id: tenantId },
    });
    const monedaCosteo = tenant.monedaBase;

    const { montoConvertido, exchangeRateId } = await this.conversionHelper.resolverConversion(
      tenantId,
      dto.montoOriginal,
      dto.monedaOriginal,
      monedaCosteo,
      dto.fechaFactura,
    );

    return this.tenantPrisma(tenantId).purchaseInvoice.create({
      data: {
        tenantId,
        supplierId: dto.supplierId,
        montoOriginal: dto.montoOriginal,
        monedaOriginal: dto.monedaOriginal,
        montoConvertido,
        exchangeRateId,
        // --- resto de campos existentes ---
      },
    });
  }

  private tenantPrisma: (tenantId: string) => any;
  private conversionHelper: any; // CurrencyConversionHelper (mismo que landed cost)
}
