// backend/src/inventory/services/landed-cost.service.spec.ts

import { Decimal } from '@prisma/client/runtime/library';
import { CotizacionNoDisponibleException } from '../../common/exceptions/cotizacion-no-disponible.exception';

describe('LandedCostService — distribución multimoneda', () => {
  it('prorratea correctamente un receiptId con líneas en USD y PYG', async () => {
    jest.spyOn(currencyService, 'resolveRate').mockResolvedValue({
      cotizacion: new Decimal('7500'),
      exchangeRateId: 'rate-usd-pyg',
    });

    await service.agregarLineaCosto('tenant-1', 'receipt-1', {
      montoOriginal: new Decimal('100'),
      monedaOriginal: 'USD',
      fechaFactura: new Date('2026-08-01'),
      tipo: 'FLETE_INTERNACIONAL',
    });

    await service.agregarLineaCosto('tenant-1', 'receipt-1', {
      montoOriginal: new Decimal('300000'),
      monedaOriginal: 'PYG',
      fechaFactura: new Date('2026-08-01'),
      tipo: 'ADUANA',
    });

    const distribucion = await service.distribuirCostoPorReceipt('tenant-1', 'receipt-1');

    // 100 USD * 7500 = 750.000 PYG + 300.000 PYG = 1.050.000 PYG total a prorratear
    expect(distribucion.totalConvertido).toEqual(new Decimal('1050000'));
    expect(distribucion.moneda).toBe('PYG');
  });

  it('lanza CotizacionNoDisponibleException si no hay dato histórico ni manual', async () => {
    jest.spyOn(currencyService, 'resolveRate').mockResolvedValue(null);

    await expect(
      service.agregarLineaCosto('tenant-1', 'receipt-1', {
        montoOriginal: new Decimal('50'),
        monedaOriginal: 'EUR',
        fechaFactura: new Date('2026-06-01'),
        tipo: 'ESTIBADORES',
      }),
    ).rejects.toThrow(CotizacionNoDisponibleException);
  });

  it('no requiere cotización cuando monedaOriginal ya es la moneda de costeo', async () => {
    const resolveRateSpy = jest.spyOn(currencyService, 'resolveRate');

    const linea = await service.agregarLineaCosto('tenant-1', 'receipt-1', {
      montoOriginal: new Decimal('200000'),
      monedaOriginal: 'PYG',
      fechaFactura: new Date('2026-08-01'),
      tipo: 'ESTIBADORES',
    });

    expect(resolveRateSpy).not.toHaveBeenCalled();
    expect(linea.exchangeRateId).toBeNull();
    expect(linea.montoConvertido).toEqual(linea.montoOriginal);
  });
});
