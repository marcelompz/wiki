// backend/src/inventory/services/landed-cost.service.ts
//
// Agregar/reemplazar el método agregarLineaCosto() de la clase existente
// con esta versión, que usa el helper compartido resolverConversion().

import { AgregarLineaCostoDto } from '../dto/agregar-linea-costo.dto';

export class LandedCostServiceAdditions {
  async agregarLineaCosto(tenantId: string, receiptId: string, dto: AgregarLineaCostoDto) {
    const tenant = await this.tenantPrisma(tenantId).tenant.findUniqueOrThrow({
      where: { id: tenantId },
    });
    const monedaCosteo = tenant.monedaBase;

    const { montoConvertido, exchangeRateId } = await this.conversionHelper.resolverConversion(
      tenantId,
      dto.montoOriginal,
      dto.monedaOriginal,
      monedaCosteo,
      dto.fechaFactura,
    );

    return this.tenantPrisma(tenantId).costAdjustment.create({
      data: {
        tenantId,
        receiptId,
        montoOriginal: dto.montoOriginal,
        monedaOriginal: dto.monedaOriginal,
        montoConvertido,
        exchangeRateId,
        // --- resto de campos existentes (tipo, descripción, etc.) ---
      },
    });
  }

  // La distribución por promedio ponderado sigue corriendo siempre sobre
  // montoConvertido (moneda de costeo del tenant), nunca sobre montoOriginal
  // — así un receiptId con líneas en distintas monedas queda comparable.
  async distribuirCostoPorReceipt(tenantId: string, receiptId: string) {
    const lineas = await this.tenantPrisma(tenantId).costAdjustment.findMany({
      where: { tenantId, receiptId },
    });

    const totalConvertido = lineas.reduce(
      (acc: any, linea: any) => acc.add(linea.montoConvertido),
      new (this as any).Decimal(0),
    );

    // ...lógica de prorrateo por promedio ponderado existente, sin cambios,
    // usando totalConvertido en vez de sumar montos en distintas monedas.

    return { totalConvertido, moneda: (await this.monedaCosteoDe(tenantId)) };
  }

  private tenantPrisma: (tenantId: string) => any;
  private conversionHelper: any; // CurrencyConversionHelper
  private monedaCosteoDe: (tenantId: string) => Promise<string>;
}
