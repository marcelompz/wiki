// backend/src/common/services/currency.service.ts
//
// Agregar este método a la clase CurrencyService existente.
// No reemplaza obtenerCotizacionVigente() (caché 30 min + dolarapi +
// fallback estático) — lo envuelve y le agrega historización + resolución
// retroactiva por fecha.

import { Decimal } from '@prisma/client/runtime/library';

interface ResolveRateResult {
  cotizacion: Decimal;
  exchangeRateId: string;
}

export class CurrencyServiceAdditions {
  /**
   * Resuelve la cotización a usar entre dos monedas para un tenant.
   *
   * - Sin `fecha` (o fecha = hoy): usa el flujo actual (caché + API +
   *   fallback) y además persiste el resultado en ExchangeRateHistory
   *   (fuente = API) como efecto secundario, para poder consultarlo
   *   retroactivamente más adelante.
   * - Con `fecha` pasada: consulta ExchangeRateHistory por la cotización
   *   vigente más cercana a esa fecha (<=). No toca caché ni API — el
   *   caché en memoria solo representa el valor de "ahora".
   *
   * Devuelve `null` explícito cuando no hay dato disponible. Nunca
   * inventa un valor por defecto: eso queda a criterio del llamador
   * (típicamente, ofrecer carga manual vía POST /exchange-rates/manual).
   */
  async resolveRate(
    tenantId: string,
    monedaOrigen: string,
    monedaDestino: string,
    fecha?: Date,
  ): Promise<ResolveRateResult | null> {
    const esConsultaActual = !fecha || this.esHoy(fecha);

    if (esConsultaActual) {
      const cotizacionActual = await this.obtenerCotizacionVigente(monedaOrigen, monedaDestino);
      if (!cotizacionActual) return null;

      const registro = await this.tenantPrisma(tenantId).exchangeRateHistory.create({
        data: {
          tenantId,
          monedaOrigen,
          monedaDestino,
          cotizacion: cotizacionActual,
          fechaEfectiva: new Date(),
          fuente: 'API',
        },
      });

      return { cotizacion: registro.cotizacion, exchangeRateId: registro.id };
    }

    const registroHistorico = await this.tenantPrisma(tenantId).exchangeRateHistory.findFirst({
      where: {
        tenantId,
        monedaOrigen,
        monedaDestino,
        fechaEfectiva: { lte: fecha },
      },
      orderBy: { fechaEfectiva: 'desc' },
    });

    if (!registroHistorico) return null;

    return { cotizacion: registroHistorico.cotizacion, exchangeRateId: registroHistorico.id };
  }

  private esHoy(fecha: Date): boolean {
    const hoy = new Date();
    return (
      fecha.getFullYear() === hoy.getFullYear() &&
      fecha.getMonth() === hoy.getMonth() &&
      fecha.getDate() === hoy.getDate()
    );
  }

  // obtenerCotizacionVigente(...) y tenantPrisma(...) ya existen en la
  // clase real — se referencian acá solo para que el snippet sea legible
  // de forma aislada.
  private obtenerCotizacionVigente: (origen: string, destino: string) => Promise<Decimal | null>;
  private tenantPrisma: (tenantId: string) => any;
}
