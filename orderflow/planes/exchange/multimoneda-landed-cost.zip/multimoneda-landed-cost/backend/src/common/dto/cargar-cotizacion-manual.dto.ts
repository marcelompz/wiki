// backend/src/common/dto/cargar-cotizacion-manual.dto.ts

import { IsString, IsDecimal, IsDateString } from 'class-validator';

export class CargarCotizacionManualDto {
  @IsString()
  monedaOrigen: string;

  @IsString()
  monedaDestino: string;

  @IsDecimal()
  cotizacion: string;

  @IsDateString()
  fechaEfectiva: string;
}
