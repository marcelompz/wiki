// backend/src/common/controllers/exchange-rate.controller.ts

import { Body, Controller, Post } from '@nestjs/common';
import { TenantId } from '../decorators/tenant-id.decorator';
import { CurrentUser } from '../decorators/current-user.decorator';
import { CargarCotizacionManualDto } from '../dto/cargar-cotizacion-manual.dto';

@Controller()
export class ExchangeRateController {
  constructor(private readonly tenantPrisma: any /* @TenantPrisma() provider */) {}

  @Post('exchange-rates/manual')
  async cargarCotizacionManual(
    @TenantId() tenantId: string,
    @CurrentUser() userId: string,
    @Body() dto: CargarCotizacionManualDto,
  ) {
    return this.tenantPrisma(tenantId).exchangeRateHistory.create({
      data: {
        tenantId,
        monedaOrigen: dto.monedaOrigen,
        monedaDestino: dto.monedaDestino,
        cotizacion: dto.cotizacion,
        fechaEfectiva: dto.fechaEfectiva,
        fuente: 'MANUAL',
        cargadoPor: userId,
      },
    });
  }
}
