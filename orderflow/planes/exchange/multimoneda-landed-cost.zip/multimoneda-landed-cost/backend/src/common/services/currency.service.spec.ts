// backend/src/common/services/currency.service.spec.ts

import { Decimal } from '@prisma/client/runtime/library';

describe('CurrencyService.resolveRate', () => {
  it('resuelve cotización actual desde caché/API y la historiza (fuente=API)', async () => {
    jest.spyOn(service as any, 'obtenerCotizacionVigente').mockResolvedValue(new Decimal('7500'));
    const createSpy = jest.spyOn(prisma.exchangeRateHistory, 'create').mockResolvedValue({
      id: 'rate-1',
      cotizacion: new Decimal('7500'),
      fuente: 'API',
    } as any);

    const resultado = await service.resolveRate('tenant-1', 'USD', 'PYG');

    expect(resultado).toEqual({ cotizacion: new Decimal('7500'), exchangeRateId: 'rate-1' });
    expect(createSpy).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ fuente: 'API' }) }),
    );
  });

  it('resuelve cotización histórica existente sin tocar caché ni API', async () => {
    const apiSpy = jest.spyOn(service as any, 'obtenerCotizacionVigente');
    jest.spyOn(prisma.exchangeRateHistory, 'findFirst').mockResolvedValue({
      id: 'rate-historico',
      cotizacion: new Decimal('7200'),
    } as any);

    const fechaPasada = new Date('2026-07-15');
    const resultado = await service.resolveRate('tenant-1', 'USD', 'PYG', fechaPasada);

    expect(resultado).toEqual({ cotizacion: new Decimal('7200'), exchangeRateId: 'rate-historico' });
    expect(apiSpy).not.toHaveBeenCalled();
  });

  it('devuelve null cuando no hay cotización histórica para la fecha (nunca un valor por defecto)', async () => {
    jest.spyOn(prisma.exchangeRateHistory, 'findFirst').mockResolvedValue(null);

    const resultado = await service.resolveRate('tenant-1', 'USD', 'PYG', new Date('2020-01-01'));

    expect(resultado).toBeNull();
  });

  it('nunca mezcla el historial entre tenants distintos', async () => {
    const findFirstSpy = jest.spyOn(prisma.exchangeRateHistory, 'findFirst').mockResolvedValue(null);

    await service.resolveRate('tenant-2', 'USD', 'PYG', new Date('2026-07-15'));

    expect(findFirstSpy).toHaveBeenCalledWith(
      expect.objectContaining({ where: expect.objectContaining({ tenantId: 'tenant-2' }) }),
    );
  });
});
