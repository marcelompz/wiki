// backend/src/common/services/currency-conversion.helper.ts
//
// Punto único de "resolver cotización + convertir monto", compartido entre
// landed cost, compras, y cualquier módulo futuro que registre montos en
// moneda distinta a la de costeo del tenant. Ver regla 5 de la sección
// multimoneda en docs/00-contexto-agentes.md — prohibido reimplementar
// este cálculo por módulo.

import { Decimal } from '@prisma/client/runtime/library';
import { CotizacionNoDisponibleException } from '../exceptions/cotizacion-no-disponible.exception';

export class CurrencyConversionHelper {
  constructor(private readonly currencyService: any /* CurrencyService */) {}

  async resolverConversion(
    tenantId: string,
    montoOriginal: Decimal,
    monedaOriginal: string,
    monedaDestino: string,
    fecha: Date,
  ): Promise<{ montoConvertido: Decimal; exchangeRateId: string | null }> {
    if (monedaOriginal === monedaDestino) {
      return { montoConvertido: montoOriginal, exchangeRateId: null };
    }

    const resultado = await this.currencyService.resolveRate(
      tenantId,
      monedaOriginal,
      monedaDestino,
      fecha,
    );

    if (!resultado) {
      throw new CotizacionNoDisponibleException(monedaOriginal, monedaDestino, fecha);
    }

    return {
      montoConvertido: montoOriginal.mul(resultado.cotizacion),
      exchangeRateId: resultado.exchangeRateId,
    };
  }
}
