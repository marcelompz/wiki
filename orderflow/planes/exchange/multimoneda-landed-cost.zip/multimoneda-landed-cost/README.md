# FEAT-082 — Historial de Cotizaciones y Landed Cost Multimoneda

Paquete con todo lo desarrollado en la conversación de diseño: modelo de datos,
servicios, DTOs, endpoint de carga manual, tests unitarios, E2E, directrices
para AGENTS.md y la entrada de featurelist.json.

Estos archivos son **snippets para integrar** en el repo real de OrderFlow
(`github.com/marcelompz/orderflow`), no un proyecto standalone — respetan la
estructura de carpetas del monorepo (`backend/src/...`, `docs/...`) para que
sea directo copiarlos a su lugar.

## Contenido

```
backend/
  prisma/
    migrations/20260822000000_add_exchange_rate_history/
      migration.sql          -> SQL de la migración (tabla + enum + índice + FK)
    schema.additions.prisma  -> Modelos/enums a agregar a schema.prisma
  src/
    common/
      services/
        currency.service.additions.ts        -> método resolveRate() a agregar a CurrencyService existente
        currency.service.spec.ts             -> tests unitarios de resolveRate
        currency-conversion.helper.ts        -> helper compartido resolverConversion()
      controllers/
        exchange-rate.controller.ts          -> endpoint POST /exchange-rates/manual
      dto/
        cargar-cotizacion-manual.dto.ts
    inventory/
      services/
        landed-cost.service.additions.ts     -> agregarLineaCosto() extendido
        landed-cost.service.spec.ts          -> tests de distribución multimoneda
    purchasing/
      services/
        purchase-invoice.service.additions.ts -> registrarFactura() extendido
e2e/
  landed-cost-multimoneda.spec.ts            -> test E2E Playwright
docs/
  AGENTS-multimoneda-seccion.md              -> sección para pegar en docs/00-contexto-agentes.md / AGENTS.md
  featurelist-FEAT-082.json                  -> entrada para agregar a featurelist.json
  plan-completo.md                           -> resumen del plan en etapas (para ROADMAP.md / referencia)
```

## Orden de integración sugerido

1. Aplicar `schema.additions.prisma` al `schema.prisma` real y correr la migración.
2. Agregar `resolveRate()` a `currency.service.ts` existente (no reemplaza el
   método de caché/API actual, lo envuelve).
3. Agregar `currency-conversion.helper.ts` y el controller/DTO de carga manual.
4. Extender `CostAdjustment` (landed-cost.service) y `PurchaseInvoice`
   (purchase-invoice.service) usando el helper compartido.
5. Copiar los tests y correrlos (`./scripts/init.sh` **solo con confirmación
   explícita**, según AGENTS.md).
6. Pegar la sección de `docs/AGENTS-multimoneda-seccion.md` en
   `docs/00-contexto-agentes.md`.
7. Agregar la entrada `docs/featurelist-FEAT-082.json` a `featurelist.json`
   real y sincronizar `ROADMAP.md`/`CHANGELOG.md`/`VERSION` según el
   protocolo de 3 roles (Planificador/Implementador/Revisor).

## Estado

Diseño y código de referencia completos (Etapas 0, 1, 2, 3 y directrices).
Pendiente: Etapa 4 — integración real en el repo, sync de versión y
ejecución de `./scripts/init.sh`.
