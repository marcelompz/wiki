import * as XLSX from 'xlsx';
import { ExportFormat, FileMetadata } from '../types';

export interface ParseResult {
  data: any;
  metadata: FileMetadata;
  workbook?: XLSX.WorkBook;
}

/**
 * Reads and parses JSON, CSV, and XLSX client-side.
 */
export async function parseUploadedFile(file: File): Promise<ParseResult> {
  const isJson = file.name.toLowerCase().endsWith('.json');
  const isCsv = file.name.toLowerCase().endsWith('.csv');
  const isXlsx = file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls');

  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onerror = () => reject(new Error(`Error al leer el archivo ${file.name}`));

    if (isJson) {
      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          const parsed = JSON.parse(text);
          resolve({
            data: parsed,
            metadata: {
              name: file.name,
              size: file.size,
              type: 'application/json',
              lastModified: file.lastModified,
            },
          });
        } catch (err: any) {
          reject(new Error(`JSON inválido: ${err.message}`));
        }
      };
      reader.readAsText(file);
    } else {
      // CSV or Excel
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const sheetNames = workbook.SheetNames;
          if (!sheetNames || sheetNames.length === 0) {
            throw new Error('El libro de cálculo no contiene hojas.');
          }

          const activeSheet = sheetNames[0];
          const sheet = workbook.Sheets[activeSheet];
          const sheetData = XLSX.utils.sheet_to_json(sheet, { defval: '' });

          resolve({
            data: sheetData,
            workbook,
            metadata: {
              name: file.name,
              size: file.size,
              type: isCsv ? 'text/csv' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
              lastModified: file.lastModified,
              sheetCount: sheetNames.length,
              sheetNames,
              activeSheet,
            },
          });
        } catch (err: any) {
          reject(new Error(`Error al procesar archivo de hoja de cálculo: ${err.message}`));
        }
      };
      reader.readAsBinaryString(file);
    }
  });
}

/**
 * Export unified JSON data to JSON, CSV, or XLSX
 */
export function exportDataToFile(
  data: any,
  format: ExportFormat,
  options?: {
    filename?: string;
    sheetName?: string;
  }
) {
  const baseName = options?.filename || 'omniflow_export';
  const fileName = `${baseName}.${format}`;
  const sheetName = options?.sheetName || 'OmniFlow Data';

  if (format === 'json') {
    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    return;
  }

  // Format is 'xlsx' or 'csv'
  let rowsToExport: any[] = [];

  if (Array.isArray(data)) {
    // If it's an array of objects or primitives
    rowsToExport = data.map((item) => {
      if (item !== null && typeof item === 'object') {
        // Flatten 1-level deep objects or stringify nested arrays/objects for CSV/XLSX
        const flatItem: Record<string, any> = {};
        for (const [key, val] of Object.entries(item)) {
          if (val !== null && typeof val === 'object') {
            flatItem[key] = JSON.stringify(val);
          } else {
            flatItem[key] = val;
          }
        }
        return flatItem;
      }
      return { value: item };
    });
  } else if (typeof data === 'object' && data !== null) {
    // Single object: export as key-value pairs or single row
    rowsToExport = [data];
  } else {
    rowsToExport = [{ value: data }];
  }

  const worksheet = XLSX.utils.json_to_sheet(rowsToExport);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);

  if (format === 'csv') {
    XLSX.writeFile(workbook, fileName, { bookType: 'csv' });
  } else {
    XLSX.writeFile(workbook, fileName, { bookType: 'xlsx' });
  }
}

/**
 * Format bytes to readable string (e.g. 14.2 KB)
 */
export function formatBytes(bytes: number, decimals = 1): string {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}
