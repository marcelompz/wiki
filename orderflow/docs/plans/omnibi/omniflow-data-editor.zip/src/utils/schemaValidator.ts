import { OdooModelSchema, ValidationError } from '../types';

export const ODOO_SCHEMAS: Record<string, OdooModelSchema> = {
  'res.partner': {
    id: 'res.partner',
    name: 'Contactos y Empresas (res.partner)',
    odooModel: 'res.partner',
    description: 'Modelo de contactos de Odoo para clientes, proveedores y compañías.',
    fields: [
      { name: 'name', label: 'Nombre / Razón Social', type: 'string', required: true },
      { name: 'email', label: 'Correo Electrónico', type: 'email' },
      { name: 'phone', label: 'Teléfono', type: 'string' },
      { name: 'is_company', label: 'Es Empresa', type: 'boolean' },
      { name: 'city', label: 'Ciudad', type: 'string' },
      { name: 'active', label: 'Activo', type: 'boolean' },
    ],
  },
  'product.template': {
    id: 'product.template',
    name: 'Plantilla de Productos (product.template)',
    odooModel: 'product.template',
    description: 'Catálogo de artículos, servicios y consumibles en Odoo.',
    fields: [
      { name: 'default_code', label: 'Referencia Interna (SKU)', type: 'string' },
      { name: 'name', label: 'Nombre del Producto', type: 'string', required: true },
      { name: 'list_price', label: 'Precio de Venta', type: 'number', required: true, min: 0 },
      { name: 'standard_price', label: 'Costo Estándar', type: 'number', min: 0 },
      { name: 'type', label: 'Tipo de Producto', type: 'select', options: ['consu', 'service', 'product'] },
      { name: 'active', label: 'Disponible', type: 'boolean' },
    ],
  },
  'sale.order': {
    id: 'sale.order',
    name: 'Pedidos de Venta (sale.order)',
    odooModel: 'sale.order',
    description: 'Órdenes de presupuesto y ventas con totales y cliente.',
    fields: [
      { name: 'name', label: 'Número de Pedido', type: 'string', required: true },
      { name: 'partner_id', label: 'Cliente (ID o Nombre)', type: 'string', required: true },
      { name: 'amount_total', label: 'Monto Total', type: 'number', required: true, min: 0 },
      { name: 'state', label: 'Estado', type: 'select', options: ['draft', 'sent', 'sale', 'done', 'cancel'] },
    ],
  },
  'omniflow.workflow': {
    id: 'omniflow.workflow',
    name: 'Pipeline de Automatización (omniflow.workflow)',
    odooModel: 'omniflow.workflow',
    description: 'Estructura jerárquica de automatización para el motor OmniFlow.',
    fields: [
      { name: 'id', label: 'Identificador Único', type: 'string', required: true },
      { name: 'name', label: 'Nombre del Flujo', type: 'string', required: true },
      { name: 'version', label: 'Versión Semántica', type: 'string', required: true },
      { name: 'enabled', label: 'Activo en OmniFlow', type: 'boolean' },
      { name: 'triggers', label: 'Disparadores (Triggers)', type: 'array', required: true },
      { name: 'steps', label: 'Pasos de Ejecución (Steps)', type: 'array', required: true },
    ],
  },
};

/**
 * Validates data (either an array of records or a single object) against an Odoo/OmniFlow schema
 */
export function validateDataAgainstSchema(data: any, schemaId: string): ValidationError[] {
  if (!schemaId || !ODOO_SCHEMAS[schemaId]) return [];
  const schema = ODOO_SCHEMAS[schemaId];
  const errors: ValidationError[] = [];

  const validateRecord = (record: any, index?: number, pathPrefix = '') => {
    if (!record || typeof record !== 'object') {
      errors.push({
        path: pathPrefix || 'root',
        row: index,
        message: 'El registro no es un objeto válido',
        severity: 'error',
        rule: 'invalid_type',
      });
      return;
    }

    for (const field of schema.fields) {
      const value = record[field.name];
      const fieldPath = pathPrefix ? `${pathPrefix}.${field.name}` : field.name;

      // Required check
      if (field.required && (value === undefined || value === null || value === '')) {
        errors.push({
          path: fieldPath,
          row: index,
          field: field.name,
          message: `El campo obligatorio "${field.label}" está vacío.`,
          severity: 'error',
          rule: 'required',
        });
        continue;
      }

      // If optional and missing, pass
      if (value === undefined || value === null || value === '') {
        continue;
      }

      // Type checks
      if (field.type === 'number') {
        const num = Number(value);
        if (isNaN(num)) {
          errors.push({
            path: fieldPath,
            row: index,
            field: field.name,
            message: `"${field.label}" debe ser numérico. Valor recibido: "${value}".`,
            severity: 'error',
            rule: 'type_number',
          });
        } else if (field.min !== undefined && num < field.min) {
          errors.push({
            path: fieldPath,
            row: index,
            field: field.name,
            message: `"${field.label}" no puede ser menor a ${field.min}.`,
            severity: 'warning',
            rule: 'min_value',
          });
        }
      } else if (field.type === 'email') {
        const emailStr = String(value);
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailStr)) {
          errors.push({
            path: fieldPath,
            row: index,
            field: field.name,
            message: `"${value}" no tiene un formato de correo electrónico válido.`,
            severity: 'warning',
            rule: 'email_format',
          });
        }
      } else if (field.type === 'boolean') {
        const isBool = typeof value === 'boolean' || value === 'true' || value === 'false' || value === 1 || value === 0;
        if (!isBool) {
          errors.push({
            path: fieldPath,
            row: index,
            field: field.name,
            message: `"${field.label}" debe ser un valor booleano (verdadero/falso).`,
            severity: 'warning',
            rule: 'type_boolean',
          });
        }
      } else if (field.type === 'select' && field.options) {
        if (!field.options.includes(String(value))) {
          errors.push({
            path: fieldPath,
            row: index,
            field: field.name,
            message: `Valor "${value}" inválido. Permitidos: ${field.options.join(', ')}.`,
            severity: 'error',
            rule: 'enum_option',
          });
        }
      } else if (field.type === 'array') {
        if (!Array.isArray(value)) {
          errors.push({
            path: fieldPath,
            row: index,
            field: field.name,
            message: `"${field.label}" debe ser una lista o arreglo (Array).`,
            severity: 'error',
            rule: 'type_array',
          });
        }
      }
    }
  };

  if (Array.isArray(data)) {
    data.forEach((row, idx) => {
      validateRecord(row, idx, `fila[${idx + 1}]`);
    });
  } else if (data && typeof data === 'object') {
    validateRecord(data, undefined, 'root');
  }

  return errors;
}
