export const SAMPLE_ODOO_PARTNERS = [
  {
    name: 'Agrolait Inc.',
    email: 'contact@agrolait.com',
    phone: '+32 81 813700',
    is_company: true,
    city: 'Wavre',
    active: true,
  },
  {
    name: 'Brandon Freeman',
    email: 'brandon.freeman@example.com',
    phone: '+1 555-0199',
    is_company: false,
    city: 'San Francisco',
    active: true,
  },
  {
    name: 'Deco Addict Studio',
    email: 'info@decoaddict.org',
    phone: '+1 555-0143',
    is_company: true,
    city: 'New York',
    active: true,
  },
  {
    name: 'Camila Rodriguez',
    email: 'crodriguez@innovatech.es',
    phone: '+34 912 345 678',
    is_company: false,
    city: 'Madrid',
    active: true,
  },
  {
    name: 'Lumber Inc.',
    email: 'orders@lumberinc.com',
    phone: '+1 555-0182',
    is_company: true,
    city: 'Seattle',
    active: false,
  },
];

export const SAMPLE_ODOO_PRODUCTS = [
  {
    default_code: 'DESK001',
    name: 'Escritorio Ergonómico Omni',
    list_price: 289.5,
    standard_price: 145.0,
    type: 'product',
    active: true,
  },
  {
    default_code: 'CHAIR042',
    name: 'Silla Ejecutiva Pro Mesh',
    list_price: 175.0,
    standard_price: 92.0,
    type: 'product',
    active: true,
  },
  {
    default_code: 'SERV009',
    name: 'Consultoría e Integración OmniFlow',
    list_price: 95.0,
    standard_price: 40.0,
    type: 'service',
    active: true,
  },
  {
    default_code: 'CAB003',
    name: 'Archivador Metálico 3 Gavetas',
    list_price: 120.0,
    standard_price: 65.0,
    type: 'consu',
    active: true,
  },
];

export const SAMPLE_OMNIFLOW_PIPELINE = {
  id: 'flow_lead_qualification_v2',
  name: 'OmniFlow Sync & Lead Qualification Pipeline',
  version: '2.4.1',
  enabled: true,
  triggers: [
    {
      type: 'webhook',
      endpoint: '/api/v1/omniflow/incoming-lead',
      method: 'POST',
      auth: 'bearer_token',
    },
    {
      type: 'cron',
      schedule: '0 */6 * * *',
      description: 'Verificación periódica de leads en cola',
    },
  ],
  context: {
    tenant: 'enterprise_01',
    environment: 'production',
    retryPolicy: {
      maxRetries: 3,
      backoffMs: 1500,
    },
  },
  steps: [
    {
      stepId: 'validate_payload',
      action: 'schema.validate',
      targetModel: 'res.partner',
      strictMode: true,
      onFailure: 'abort_with_notification',
    },
    {
      stepId: 'enrich_crm_data',
      action: 'odoo.read',
      model: 'crm.lead',
      domain: "[('email', '=', payload.email)]",
      fields: ['id', 'user_id', 'stage_id', 'expected_revenue'],
    },
    {
      stepId: 'condition_decision',
      action: 'flow.condition',
      condition: 'payload.expected_revenue > 10000',
      branches: {
        trueBranch: {
          action: 'odoo.create',
          model: 'mail.activity',
          summary: 'Atención Prioritaria: Gran Cuenta',
          dueDays: 1,
        },
        falseBranch: {
          action: 'odoo.write',
          model: 'crm.lead',
          stage: 'qualified_standard',
        },
      },
    },
    {
      stepId: 'dispatch_event',
      action: 'webhook.send',
      url: 'https://webhook.omniflow.internal/events/lead-ready',
      payloadFields: ['lead_id', 'status', 'score'],
    },
  ],
};
