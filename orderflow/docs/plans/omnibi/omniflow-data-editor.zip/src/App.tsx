import React from 'react';
import { OmniFlowDataEditor } from './components/OmniFlowDataEditor';

export default function App() {
  return (
    <div className="min-h-screen bg-stone-100 flex flex-col font-sans">
      <OmniFlowDataEditor />
    </div>
  );
}
