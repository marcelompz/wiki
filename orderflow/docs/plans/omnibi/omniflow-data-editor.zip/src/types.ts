export type ViewMode = 'table' | 'tree' | 'raw';
export type ExportFormat = 'json' | 'csv' | 'xlsx';

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonObject | JsonArray;
export interface JsonObject {
  [key: string]: JsonValue;
}
export type JsonArray = JsonValue[];

export type EditorData = any;

export interface ValidationError {
  path: string; // e.g. "rows[2].email" or "data.version"
  row?: number;
  field?: string;
  message: string;
  severity: 'error' | 'warning';
  rule?: string;
}

export interface SchemaField {
  name: string;
  label: string;
  type: 'string' | 'number' | 'boolean' | 'email' | 'select' | 'array' | 'object';
  required?: boolean;
  options?: string[]; // for select
  min?: number;
  max?: number;
  description?: string;
}

export interface OdooModelSchema {
  id: string;
  name: string;
  odooModel: string;
  description: string;
  fields: SchemaField[];
}

export interface FileMetadata {
  name: string;
  size: number;
  type: string;
  lastModified?: number;
  sheetCount?: number;
  sheetNames?: string[];
  activeSheet?: string;
}
