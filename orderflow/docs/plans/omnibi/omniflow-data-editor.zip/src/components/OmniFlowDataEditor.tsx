import React, { useState, useRef, useEffect, useMemo } from 'react';
import * as XLSX from 'xlsx';
import {
  Table as TableIcon,
  FolderTree,
  Code2,
  Upload,
  Download,
  FileSpreadsheet,
  FileCode,
  Layers,
  ChevronDown,
  CheckCircle2,
  AlertCircle,
  FileText,
  Sparkles,
  Info,
  Package,
  Share2
} from 'lucide-react';
import { ViewMode, ExportFormat, FileMetadata, ValidationError } from '../types';
import { exportDataToFile, formatBytes } from '../utils/fileParser';
import { validateDataAgainstSchema, ODOO_SCHEMAS } from '../utils/schemaValidator';
import { TableView } from './TableView';
import { TreeView } from './TreeView';
import { RawView } from './RawView';
import { ValidationPanel } from './ValidationPanel';
import { EmbedCodeModal } from './EmbedCodeModal';
import { SAMPLE_ODOO_PARTNERS, SAMPLE_ODOO_PRODUCTS, SAMPLE_OMNIFLOW_PIPELINE } from '../data/samples';

export interface OmniFlowDataEditorProps {
  initialData?: any;
  onChange?: (data: any) => void;
  defaultView?: ViewMode;
  schema?: string;
  className?: string;
  readOnly?: boolean;
}

export function OmniFlowDataEditor({
  initialData,
  onChange: onExternalChange,
  defaultView = 'table',
  schema: externalSchema = 'res.partner',
  className = '',
  readOnly = false,
}: OmniFlowDataEditorProps) {
  // 1. Unified state: always JavaScript Object or Array (native JSON)
  const [data, setData] = useState<any>(() => {
    if (initialData !== undefined) return initialData;
    return SAMPLE_ODOO_PARTNERS;
  });

  const [viewMode, setViewMode] = useState<ViewMode>(defaultView);
  const [selectedSchema, setSelectedSchema] = useState<string>(externalSchema);
  const [activeFileMeta, setActiveFileMeta] = useState<FileMetadata | null>({
    name: 'res_partner_sample.xlsx',
    size: 14200,
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    activeSheet: 'Contactos Odoo',
    sheetNames: ['Contactos Odoo'],
  });

  // Cached workbook if file was an Excel with multiple sheets
  const [loadedWorkbook, setLoadedWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showSamplesMenu, setShowSamplesMenu] = useState(false);
  const [showEmbedModal, setShowEmbedModal] = useState(false);
  const [showValidationDrawer, setShowValidationDrawer] = useState(true);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync with external initialData if provided and changed
  useEffect(() => {
    if (initialData !== undefined) {
      setData(initialData);
    }
  }, [initialData]);

  // Centralized change handler that calls internal state and optional external callback
  const handleDataChange = (newData: any) => {
    if (readOnly) return;
    setData(newData);
    if (onExternalChange) {
      onExternalChange(newData);
    }
  };

  // 1. Unified Import engine (JSON, CSV, XLSX)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processFile(file);
    // reset input so same file can be uploaded again
    e.target.value = '';
  };

  const processFile = (file: File) => {
    const reader = new FileReader();

    if (file.name.toLowerCase().endsWith('.json')) {
      reader.onload = (evt) => {
        try {
          const parsed = JSON.parse(evt.target?.result as string);
          handleDataChange(parsed);
          setActiveFileMeta({
            name: file.name,
            size: file.size,
            type: 'application/json',
            lastModified: file.lastModified,
          });
          setLoadedWorkbook(null);
          // Suggest Tree View if object, or Table if array
          if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'object') {
            setViewMode('table');
          } else {
            setViewMode('tree');
          }
        } catch (err: any) {
          alert(`Error al analizar JSON: ${err.message}`);
        }
      };
      reader.readAsText(file);
    } else {
      // Handles both XLSX and CSV via SheetJS
      reader.onload = (evt) => {
        try {
          const binaryData = evt.target?.result;
          const workbook = XLSX.read(binaryData, { type: 'binary' });
          const sheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[sheetName];
          const sheetData = XLSX.utils.sheet_to_json(sheet, { defval: '' });

          handleDataChange(sheetData);
          setLoadedWorkbook(workbook);
          setActiveFileMeta({
            name: file.name,
            size: file.size,
            type: file.name.endsWith('.csv') ? 'text/csv' : 'application/vnd.ms-excel',
            lastModified: file.lastModified,
            sheetCount: workbook.SheetNames.length,
            sheetNames: workbook.SheetNames,
            activeSheet: sheetName,
          });
          setViewMode('table');
        } catch (err: any) {
          alert(`Error al procesar archivo de hoja de cálculo: ${err.message}`);
        }
      };
      reader.readAsBinaryString(file);
    }
  };

  // Multi-sheet switch
  const handleSwitchSheet = (sheetName: string) => {
    if (!loadedWorkbook) return;
    const sheet = loadedWorkbook.Sheets[sheetName];
    if (!sheet) return;
    const sheetData = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    handleDataChange(sheetData);
    setActiveFileMeta((prev) => (prev ? { ...prev, activeSheet: sheetName } : null));
  };

  // 2. Unified Export engine (JSON, CSV, XLSX)
  const exportFile = (format: ExportFormat) => {
    setShowExportMenu(false);
    const baseName = activeFileMeta?.name?.replace(/\.[^/.]+$/, '') || 'omniflow_data';
    exportDataToFile(data, format, {
      filename: baseName,
      sheetName: activeFileMeta?.activeSheet || 'Data',
    });
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  // Validation execution
  const validationErrors = useMemo<ValidationError[]>(() => {
    if (!selectedSchema) return [];
    return validateDataAgainstSchema(data, selectedSchema);
  }, [data, selectedSchema]);

  // Load sample dataset
  const handleLoadSample = (type: 'partners' | 'products' | 'pipeline') => {
    setShowSamplesMenu(false);
    if (type === 'partners') {
      handleDataChange(SAMPLE_ODOO_PARTNERS);
      setSelectedSchema('res.partner');
      setViewMode('table');
      setActiveFileMeta({
        name: 'odoo_contacts_res_partner.xlsx',
        size: 16500,
        type: 'application/vnd.ms-excel',
        activeSheet: 'Contactos',
        sheetNames: ['Contactos'],
      });
    } else if (type === 'products') {
      handleDataChange(SAMPLE_ODOO_PRODUCTS);
      setSelectedSchema('product.template');
      setViewMode('table');
      setActiveFileMeta({
        name: 'odoo_products_template.csv',
        size: 8900,
        type: 'text/csv',
        activeSheet: 'Productos',
      });
    } else {
      handleDataChange(SAMPLE_OMNIFLOW_PIPELINE);
      setSelectedSchema('omniflow.workflow');
      setViewMode('tree');
      setActiveFileMeta({
        name: 'omniflow_lead_pipeline.json',
        size: 24200,
        type: 'application/json',
      });
    }
  };

  const recordsCount = Array.isArray(data)
    ? data.length
    : typeof data === 'object' && data !== null
    ? Object.keys(data).length
    : 1;

  return (
    <div
      id="omniflow-editor"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`omniflow-editor flex flex-col w-full bg-stone-100 min-h-screen text-stone-900 ${className} relative`}
    >
      {/* Drag & Drop Overlay */}
      {isDragging && (
        <div className="absolute inset-0 bg-indigo-600/90 backdrop-blur-xs z-50 flex flex-col items-center justify-center text-white border-4 border-dashed border-white m-4 rounded-2xl">
          <Upload className="w-16 h-16 animate-bounce mb-3" />
          <h3 className="text-xl font-bold">Suelta tu archivo aquí</h3>
          <p className="text-sm opacity-90">Soporta archivos .JSON, .CSV y .XLSX</p>
        </div>
      )}

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json,.csv,.xlsx,.xls"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Main Top Header */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
          {/* Brand & File Info */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-600 to-indigo-800 text-white flex items-center justify-center font-bold text-base shadow-sm">
              <span className="tracking-tight">Ω</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-stone-900 text-base tracking-tight">OmniFlow</span>
                <span className="text-xs px-1.5 py-0.5 rounded bg-stone-100 text-stone-600 font-mono border border-stone-200">
                  Data Editor
                </span>
                <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-medium flex items-center gap-1 border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Client-side Engine
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-stone-500 mt-0.5">
                <span className="font-medium text-stone-700 truncate max-w-[200px]">
                  {activeFileMeta?.name || 'Archivo sin título'}
                </span>
                <span>&bull;</span>
                <span>{recordsCount} {Array.isArray(data) ? 'registros' : 'claves raíz'}</span>
                {activeFileMeta?.size ? (
                  <>
                    <span>&bull;</span>
                    <span>{formatBytes(activeFileMeta.size)}</span>
                  </>
                ) : null}
              </div>
            </div>
          </div>

          {/* Center: View Mode Switcher */}
          <div className="flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200">
            <button
              id="view-mode-table-btn"
              onClick={() => setViewMode('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                viewMode === 'table'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>Vista Tabular</span>
              <span className="text-[10px] opacity-70 font-mono">XLSX/CSV</span>
            </button>
            <button
              id="view-mode-tree-btn"
              onClick={() => setViewMode('tree')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                viewMode === 'tree'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <FolderTree className="w-3.5 h-3.5" />
              <span>Vista de Árbol</span>
              <span className="text-[10px] opacity-70 font-mono">JSON</span>
            </button>
            <button
              id="view-mode-raw-btn"
              onClick={() => setViewMode('raw')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                viewMode === 'raw'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Código Raw</span>
            </button>
          </div>

          {/* Right Toolbar: Import, Export, Samples, Embed */}
          <div className="flex items-center gap-2">
            {/* Samples Button */}
            <div className="relative">
              <button
                id="samples-dropdown-btn"
                onClick={() => setShowSamplesMenu(!showSamplesMenu)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-stone-700 bg-stone-50 hover:bg-stone-100 border border-stone-300 rounded-lg transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Muestras Odoo</span>
                <ChevronDown className="w-3 h-3 text-stone-400" />
              </button>

              {showSamplesMenu && (
                <div className="absolute right-0 mt-1 w-56 bg-white rounded-xl shadow-lg border border-stone-200 py-1.5 z-40 text-xs">
                  <div className="px-3 py-1 text-[11px] font-semibold text-stone-400 uppercase tracking-wider">
                    Cargar Modelo
                  </div>
                  <button
                    onClick={() => handleLoadSample('partners')}
                    className="w-full text-left px-3 py-2 hover:bg-stone-50 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-medium text-stone-800">Contactos Odoo</div>
                      <div className="text-[10px] text-stone-400 font-mono">res.partner (Tabla / XLSX)</div>
                    </div>
                  </button>
                  <button
                    onClick={() => handleLoadSample('products')}
                    className="w-full text-left px-3 py-2 hover:bg-stone-50 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-medium text-stone-800">Catálogo Productos</div>
                      <div className="text-[10px] text-stone-400 font-mono">product.template (CSV)</div>
                    </div>
                  </button>
                  <button
                    onClick={() => handleLoadSample('pipeline')}
                    className="w-full text-left px-3 py-2 hover:bg-stone-50 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-medium text-stone-800">Pipeline OmniFlow</div>
                      <div className="text-[10px] text-stone-400 font-mono">omniflow.workflow (Árbol JSON)</div>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {/* Import Button */}
            <button
              id="import-file-btn"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-700 bg-white hover:bg-stone-50 border border-stone-300 rounded-lg shadow-xs transition-colors"
            >
              <Upload className="w-3.5 h-3.5 text-stone-600" />
              <span>Importar</span>
            </button>

            {/* Export Dropdown */}
            <div className="relative">
              <button
                id="export-menu-btn"
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Exportar</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {showExportMenu && (
                <div className="absolute right-0 mt-1 w-48 bg-white rounded-xl shadow-lg border border-stone-200 py-1.5 z-40 text-xs">
                  <button
                    id="export-xlsx-btn"
                    onClick={() => exportFile('xlsx')}
                    className="w-full text-left px-3 py-2 hover:bg-stone-50 flex items-center gap-2 text-stone-700"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                    <div>
                      <div className="font-medium">Excel (.xlsx)</div>
                      <div className="text-[10px] text-stone-400">SheetJS nativo</div>
                    </div>
                  </button>
                  <button
                    id="export-csv-btn"
                    onClick={() => exportFile('csv')}
                    className="w-full text-left px-3 py-2 hover:bg-stone-50 flex items-center gap-2 text-stone-700"
                  >
                    <FileText className="w-4 h-4 text-blue-600" />
                    <div>
                      <div className="font-medium">Separado por Comas (.csv)</div>
                      <div className="text-[10px] text-stone-400">Compatible con Odoo import</div>
                    </div>
                  </button>
                  <button
                    id="export-json-btn"
                    onClick={() => exportFile('json')}
                    className="w-full text-left px-3 py-2 hover:bg-stone-50 flex items-center gap-2 text-stone-700 border-t border-stone-100"
                  >
                    <FileCode className="w-4 h-4 text-amber-600" />
                    <div>
                      <div className="font-medium">JSON Nativo (.json)</div>
                      <div className="text-[10px] text-stone-400">Estructura jerárquica</div>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {/* Embed in OmniFlow Core button */}
            <button
              id="embed-omniflow-btn"
              onClick={() => setShowEmbedModal(true)}
              title="Ver código de integración para OmniFlow Core"
              className="p-1.5 text-stone-500 hover:text-indigo-600 hover:bg-stone-100 rounded-lg border border-transparent hover:border-stone-200 transition-colors"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Excel Sheets bar if multiple sheets exist */}
        {activeFileMeta?.sheetNames && activeFileMeta.sheetNames.length > 1 && (
          <div className="bg-stone-50 border-t border-stone-200 px-6 py-1.5 flex items-center gap-2 text-xs">
            <span className="text-stone-500 font-medium">Hojas de cálculo:</span>
            <div className="flex gap-1">
              {activeFileMeta.sheetNames.map((sheet) => (
                <button
                  key={sheet}
                  onClick={() => handleSwitchSheet(sheet)}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                    activeFileMeta.activeSheet === sheet
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
                  }`}
                >
                  {sheet}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Main workspace container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-4">
        {/* Validation Bar */}
        <ValidationPanel
          selectedSchemaId={selectedSchema}
          onSelectSchema={setSelectedSchema}
          errors={validationErrors}
        />

        {/* View Switcher Output */}
        <div className="flex-1 min-h-[500px]">
          {viewMode === 'table' && (
            <TableView
              data={data}
              onChange={handleDataChange}
              validationErrors={validationErrors}
              onSwitchToTree={() => setViewMode('tree')}
            />
          )}

          {viewMode === 'tree' && (
            <TreeView
              data={data}
              onChange={handleDataChange}
              validationErrors={validationErrors}
            />
          )}

          {viewMode === 'raw' && (
            <RawView data={data} onChange={handleDataChange} />
          )}
        </div>
      </main>

      {/* Standalone Integration Guide Modal */}
      <EmbedCodeModal
        isOpen={showEmbedModal}
        onClose={() => setShowEmbedModal(false)}
      />
    </div>
  );
}
