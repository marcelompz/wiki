import React, { useState, useEffect } from 'react';
import { Check, Copy, AlertTriangle, Sparkles, Minimize, RefreshCw } from 'lucide-react';

interface RawViewProps {
  data: any;
  onChange: (newData: any) => void;
}

export function RawView({ data, onChange }: RawViewProps) {
  const [text, setText] = useState('');
  const [syntaxError, setSyntaxError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Sync incoming data to text
  useEffect(() => {
    try {
      const formatted = JSON.stringify(data, null, 2);
      setText(formatted || '');
      setSyntaxError(null);
      setHasUnsavedChanges(false);
    } catch (e: any) {
      setSyntaxError(`Error al formatear JSON: ${e.message}`);
    }
  }, [data]);

  const handleTextChange = (val: string) => {
    setText(val);
    setHasUnsavedChanges(true);

    try {
      const parsed = JSON.parse(val);
      setSyntaxError(null);
      // Auto-propagate if valid
      onChange(parsed);
      setHasUnsavedChanges(false);
    } catch (err: any) {
      setSyntaxError(err.message);
    }
  };

  const handlePrettify = () => {
    try {
      const parsed = JSON.parse(text);
      setText(JSON.stringify(parsed, null, 2));
      setSyntaxError(null);
      onChange(parsed);
      setHasUnsavedChanges(false);
    } catch (err: any) {
      setSyntaxError(`JSON inválido: no se puede embellecer (${err.message})`);
    }
  };

  const handleMinify = () => {
    try {
      const parsed = JSON.parse(text);
      setText(JSON.stringify(parsed));
      setSyntaxError(null);
      onChange(parsed);
      setHasUnsavedChanges(false);
    } catch (err: any) {
      setSyntaxError(`JSON inválido: no se puede compactar (${err.message})`);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="raw-view-container" className="flex flex-col h-full bg-stone-900 rounded-xl border border-stone-800 overflow-hidden shadow-xs text-stone-100">
      {/* Code Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 border-b border-stone-800 bg-stone-950/70">
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono font-medium text-stone-400">JSON Nativo</span>
          {syntaxError ? (
            <span className="inline-flex items-center gap-1 text-xs text-rose-400 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800/60">
              <AlertTriangle className="w-3.5 h-3.5" />
              Error de Sintaxis
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 text-xs text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/60">
              <Check className="w-3.5 h-3.5" />
              Sintaxis Válida
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrettify}
            title="Formatear con sangría de 2 espacios"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-300 bg-stone-800 hover:bg-stone-700 hover:text-white rounded-lg transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            Formatear (Prettify)
          </button>
          <button
            onClick={handleMinify}
            title="Compactar a una sola línea"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-300 bg-stone-800 hover:bg-stone-700 hover:text-white rounded-lg transition-colors"
          >
            <Minimize className="w-3.5 h-3.5" />
            Minificar
          </button>
          <button
            onClick={handleCopy}
            title="Copiar JSON al portapapeles"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-300 bg-stone-800 hover:bg-stone-700 hover:text-white rounded-lg transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copiado' : 'Copiar'}
          </button>
        </div>
      </div>

      {/* Editor text area */}
      <div className="relative flex-1 min-h-[420px] flex">
        <textarea
          id="raw-json-textarea"
          value={text}
          onChange={(e) => handleTextChange(e.target.value)}
          spellCheck={false}
          className="w-full h-full p-4 font-mono text-sm leading-relaxed bg-transparent text-emerald-300 focus:outline-none resize-none selection:bg-indigo-700 selection:text-white"
        />
      </div>

      {/* Footer / Error bar */}
      {syntaxError && (
        <div className="px-4 py-2 bg-rose-950/90 border-t border-rose-800 text-rose-300 text-xs font-mono">
          <strong>Parse Error:</strong> {syntaxError}
        </div>
      )}

      <div className="flex items-center justify-between px-4 py-2 bg-stone-950 border-t border-stone-800 text-xs text-stone-500 font-mono">
        <span>Carácteres: {text.length}</span>
        <span>Líneas: {text.split('\n').length}</span>
      </div>
    </div>
  );
}
