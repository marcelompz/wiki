import React, { useState } from 'react';
import {
  ChevronRight,
  ChevronDown,
  Plus,
  Trash2,
  Copy,
  Check,
  Search,
  Maximize2,
  Minimize2,
  AlertCircle
} from 'lucide-react';
import { ValidationError } from '../types';

type NodeType = 'string' | 'number' | 'boolean' | 'null' | 'object' | 'array';

function getNodeType(val: any): NodeType {
  if (val === null) return 'null';
  if (Array.isArray(val)) return 'array';
  const t = typeof val;
  if (t === 'string') return 'string';
  if (t === 'number') return 'number';
  if (t === 'boolean') return 'boolean';
  if (t === 'object') return 'object';
  return 'string';
}

function getDefaultValueForType(type: NodeType): any {
  switch (type) {
    case 'string':
      return '';
    case 'number':
      return 0;
    case 'boolean':
      return false;
    case 'null':
      return null;
    case 'array':
      return [];
    case 'object':
      return {};
  }
}

interface TreeViewProps {
  data: any;
  onChange: (newData: any) => void;
  validationErrors: ValidationError[];
}

export function TreeView({ data, onChange, validationErrors }: TreeViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedPath, setCopiedPath] = useState<string | null>(null);
  const [expandAllSignal, setExpandAllSignal] = useState<boolean | null>(null);

  // Helper to copy path
  const handleCopyPath = (path: string) => {
    navigator.clipboard.writeText(path);
    setCopiedPath(path);
    setTimeout(() => setCopiedPath(null), 2000);
  };

  // Immutably update value at path
  const updateValueAtPath = (path: (string | number)[], newValue: any) => {
    if (path.length === 0) {
      onChange(newValue);
      return;
    }

    const cloneDeep = (val: any): any => {
      if (val === null || typeof val !== 'object') return val;
      if (Array.isArray(val)) return val.map(cloneDeep);
      const res: Record<string, any> = {};
      for (const k of Object.keys(val)) {
        res[k] = cloneDeep(val[k]);
      }
      return res;
    };

    const rootCopy = cloneDeep(data);
    let curr = rootCopy;
    for (let i = 0; i < path.length - 1; i++) {
      curr = curr[path[i]];
    }
    curr[path[path.length - 1]] = newValue;
    onChange(rootCopy);
  };

  // Delete key or array item at path
  const deleteAtPath = (path: (string | number)[]) => {
    if (path.length === 0) {
      onChange({});
      return;
    }

    const cloneDeep = (val: any): any => {
      if (val === null || typeof val !== 'object') return val;
      if (Array.isArray(val)) return val.map(cloneDeep);
      const res: Record<string, any> = {};
      for (const k of Object.keys(val)) {
        res[k] = cloneDeep(val[k]);
      }
      return res;
    };

    const rootCopy = cloneDeep(data);
    let curr = rootCopy;
    for (let i = 0; i < path.length - 1; i++) {
      curr = curr[path[i]];
    }

    const lastKey = path[path.length - 1];
    if (Array.isArray(curr)) {
      curr.splice(Number(lastKey), 1);
    } else {
      delete curr[lastKey];
    }
    onChange(rootCopy);
  };

  // Rename object key
  const renameKeyAtPath = (parentPath: (string | number)[], oldKey: string, newKey: string) => {
    if (!newKey.trim() || oldKey === newKey) return;

    const cloneDeep = (val: any): any => {
      if (val === null || typeof val !== 'object') return val;
      if (Array.isArray(val)) return val.map(cloneDeep);
      const res: Record<string, any> = {};
      for (const k of Object.keys(val)) {
        res[k] = cloneDeep(val[k]);
      }
      return res;
    };

    const rootCopy = cloneDeep(data);
    let curr = rootCopy;
    for (let i = 0; i < parentPath.length; i++) {
      curr = curr[parentPath[i]];
    }

    if (curr && typeof curr === 'object' && !Array.isArray(curr)) {
      const val = curr[oldKey];
      delete curr[oldKey];
      curr[newKey] = val;
      onChange(rootCopy);
    }
  };

  // Add child to object or array
  const addChildAtPath = (path: (string | number)[], isArray: boolean) => {
    const cloneDeep = (val: any): any => {
      if (val === null || typeof val !== 'object') return val;
      if (Array.isArray(val)) return val.map(cloneDeep);
      const res: Record<string, any> = {};
      for (const k of Object.keys(val)) {
        res[k] = cloneDeep(val[k]);
      }
      return res;
    };

    const rootCopy = cloneDeep(data);
    let curr = rootCopy;
    for (let i = 0; i < path.length; i++) {
      curr = curr[path[i]];
    }

    if (isArray && Array.isArray(curr)) {
      curr.push('Nuevo valor');
      onChange(rootCopy);
    } else if (curr && typeof curr === 'object') {
      let candidateKey = 'new_key';
      let count = 1;
      while (candidateKey in curr) {
        candidateKey = `new_key_${count++}`;
      }
      curr[candidateKey] = 'valor';
      onChange(rootCopy);
    }
  };

  // Map of validation errors for quick lookup
  const errorMap = React.useMemo(() => {
    const map = new Set<string>();
    validationErrors.forEach((err) => {
      map.add(err.path.toLowerCase());
      if (err.field) map.add(err.field.toLowerCase());
    });
    return map;
  }, [validationErrors]);

  return (
    <div id="tree-view-container" className="flex flex-col h-full bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
      {/* Tree Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 border-b border-stone-200 bg-stone-50/70">
        <div className="flex items-center gap-2 flex-1 min-w-[220px] max-w-sm">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Filtrar por clave o valor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setExpandAllSignal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-700 bg-white hover:bg-stone-100 border border-stone-300 rounded-lg transition-colors"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            Expandir Todo
          </button>
          <button
            onClick={() => setExpandAllSignal(false)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-700 bg-white hover:bg-stone-100 border border-stone-300 rounded-lg transition-colors"
          >
            <Minimize2 className="w-3.5 h-3.5" />
            Contraer Todo
          </button>
        </div>
      </div>

      {/* Interactive Tree Nodes Container */}
      <div className="p-4 overflow-auto flex-1 font-mono text-sm leading-relaxed min-h-[450px]">
        {data === undefined ? (
          <div className="text-stone-400 italic p-6">Sin datos disponibles.</div>
        ) : (
          <TreeNode
            nodeKey="root"
            value={data}
            path={[]}
            isRoot={true}
            searchTerm={searchTerm}
            expandAllSignal={expandAllSignal}
            onUpdateValue={updateValueAtPath}
            onDelete={deleteAtPath}
            onRenameKey={renameKeyAtPath}
            onAddChild={addChildAtPath}
            onCopyPath={handleCopyPath}
            copiedPath={copiedPath}
            errorMap={errorMap}
          />
        )}
      </div>
    </div>
  );
}

interface TreeNodeProps {
  key?: React.Key;
  nodeKey: string | number;
  value: any;
  path: (string | number)[];
  isRoot?: boolean;
  searchTerm: string;
  expandAllSignal: boolean | null;
  onUpdateValue: (path: (string | number)[], val: any) => void;
  onDelete: (path: (string | number)[]) => void;
  onRenameKey: (parentPath: (string | number)[], oldKey: string, newKey: string) => void;
  onAddChild: (path: (string | number)[], isArray: boolean) => void;
  onCopyPath: (pathStr: string) => void;
  copiedPath: string | null;
  errorMap: Set<string>;
}

function TreeNode({
  nodeKey,
  value,
  path,
  isRoot = false,
  searchTerm,
  expandAllSignal,
  onUpdateValue,
  onDelete,
  onRenameKey,
  onAddChild,
  onCopyPath,
  copiedPath,
  errorMap,
}: TreeNodeProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [isEditingKey, setIsEditingKey] = useState(false);
  const [editedKey, setEditedKey] = useState(String(nodeKey));

  // Sync expand/collapse signals
  React.useEffect(() => {
    if (expandAllSignal !== null) {
      setIsOpen(expandAllSignal);
    }
  }, [expandAllSignal]);

  const currentType = getNodeType(value);
  const isComposite = currentType === 'object' || currentType === 'array';

  const stringPath = path.join('.');
  const hasError = errorMap.has(String(nodeKey).toLowerCase()) || (stringPath && errorMap.has(stringPath.toLowerCase()));

  // Filter visibility
  const matchesSearch = React.useMemo(() => {
    if (!searchTerm) return true;
    const q = searchTerm.toLowerCase();
    const keyMatches = String(nodeKey).toLowerCase().includes(q);
    const valMatches =
      !isComposite && value !== null && value !== undefined
        ? String(value).toLowerCase().includes(q)
        : false;
    return keyMatches || valMatches;
  }, [searchTerm, nodeKey, value, isComposite]);

  const handleTypeChange = (newType: NodeType) => {
    if (newType === currentType) return;
    const def = getDefaultValueForType(newType);
    onUpdateValue(path, def);
  };

  const handleKeySave = () => {
    setIsEditingKey(false);
    if (typeof nodeKey === 'string' && editedKey.trim() && editedKey !== nodeKey) {
      onRenameKey(path.slice(0, -1), nodeKey, editedKey.trim());
    }
  };

  return (
    <div className={`my-0.5 select-text ${!matchesSearch && !searchTerm ? '' : ''}`}>
      <div
        className={`group flex items-center gap-2 py-1 px-2 rounded-md hover:bg-stone-100/80 transition-colors ${
          hasError ? 'bg-rose-50 border border-rose-200' : ''
        }`}
      >
        {/* Toggle collapse */}
        {isComposite ? (
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-0.5 text-stone-500 hover:text-stone-800 rounded"
          >
            {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        ) : (
          <div className="w-4" />
        )}

        {/* Key or Index */}
        {!isRoot && (
          <div className="flex items-center gap-1">
            {typeof nodeKey === 'string' && !isEditingKey ? (
              <span
                onDoubleClick={() => setIsEditingKey(true)}
                className="text-indigo-950 font-semibold cursor-pointer hover:underline"
                title="Doble clic para renombrar clave"
              >
                "{nodeKey}":
              </span>
            ) : typeof nodeKey === 'string' && isEditingKey ? (
              <input
                autoFocus
                type="text"
                value={editedKey}
                onChange={(e) => setEditedKey(e.target.value)}
                onBlur={handleKeySave}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleKeySave();
                  if (e.key === 'Escape') setIsEditingKey(false);
                }}
                className="px-1.5 py-0.5 text-xs bg-white border border-indigo-500 rounded font-semibold text-indigo-900"
              />
            ) : (
              <span className="text-stone-400 font-mono text-xs select-none">[{nodeKey}]:</span>
            )}
          </div>
        )}

        {/* Value rendering & editing */}
        <div className="flex items-center gap-2 flex-1">
          {currentType === 'string' && (
            <input
              type="text"
              value={value}
              onChange={(e) => onUpdateValue(path, e.target.value)}
              className="px-2 py-0.5 text-emerald-800 bg-white border border-transparent hover:border-stone-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded text-sm min-w-[120px] max-w-md truncate"
            />
          )}

          {currentType === 'number' && (
            <input
              type="number"
              value={value}
              onChange={(e) => onUpdateValue(path, Number(e.target.value))}
              className="px-2 py-0.5 text-blue-700 bg-white border border-transparent hover:border-stone-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded text-sm w-32"
            />
          )}

          {currentType === 'boolean' && (
            <button
              onClick={() => onUpdateValue(path, !value)}
              className={`px-2 py-0.5 text-xs font-semibold rounded-full transition-colors ${
                value ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
              }`}
            >
              {value ? 'true' : 'false'}
            </button>
          )}

          {currentType === 'null' && (
            <span className="px-2 py-0.5 text-xs font-semibold bg-stone-100 text-stone-500 rounded">
              null
            </span>
          )}

          {currentType === 'object' && (
            <span className="text-stone-500 text-xs font-sans">
              {'{'} {Object.keys(value || {}).length} propiedades {'}'}
            </span>
          )}

          {currentType === 'array' && (
            <span className="text-stone-500 text-xs font-sans">
              {'['} {value.length} elementos {']'}
            </span>
          )}

          {hasError && (
            <span className="text-rose-600 flex items-center gap-1 text-xs" title="Violación de esquema">
              <AlertCircle className="w-3.5 h-3.5" />
            </span>
          )}
        </div>

        {/* Node Hover Actions */}
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          {/* Type Selector Dropdown */}
          <select
            value={currentType}
            onChange={(e) => handleTypeChange(e.target.value as NodeType)}
            className="text-xs py-0.5 px-1.5 bg-stone-100 hover:bg-stone-200 border border-stone-300 rounded text-stone-700 font-sans cursor-pointer focus:outline-none"
          >
            <option value="string">string</option>
            <option value="number">number</option>
            <option value="boolean">boolean</option>
            <option value="null">null</option>
            <option value="object">object</option>
            <option value="array">array</option>
          </select>

          {/* Add Child Property / Item */}
          {isComposite && (
            <button
              onClick={() => onAddChild(path, currentType === 'array')}
              title={currentType === 'array' ? 'Añadir elemento' : 'Añadir clave'}
              className="p-1 text-stone-500 hover:text-indigo-600 hover:bg-stone-200 rounded"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Copy Path */}
          <button
            onClick={() => onCopyPath(stringPath || 'root')}
            title="Copiar ruta JSON"
            className="p-1 text-stone-400 hover:text-stone-700 hover:bg-stone-200 rounded"
          >
            {copiedPath === (stringPath || 'root') ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Delete Node */}
          {!isRoot && (
            <button
              onClick={() => onDelete(path)}
              title="Eliminar nodo"
              className="p-1 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Children rendering */}
      {isComposite && isOpen && (
        <div className="pl-5 border-l border-stone-200 ml-3">
          {currentType === 'object' &&
            Object.keys(value || {}).map((childKey) => (
              <TreeNode
                key={childKey}
                nodeKey={childKey}
                value={value[childKey]}
                path={[...path, childKey]}
                searchTerm={searchTerm}
                expandAllSignal={expandAllSignal}
                onUpdateValue={onUpdateValue}
                onDelete={onDelete}
                onRenameKey={onRenameKey}
                onAddChild={onAddChild}
                onCopyPath={onCopyPath}
                copiedPath={copiedPath}
                errorMap={errorMap}
              />
            ))}

          {currentType === 'array' &&
            value.map((item: any, idx: number) => (
              <TreeNode
                key={idx}
                nodeKey={idx}
                value={item}
                path={[...path, idx]}
                searchTerm={searchTerm}
                expandAllSignal={expandAllSignal}
                onUpdateValue={onUpdateValue}
                onDelete={onDelete}
                onRenameKey={onRenameKey}
                onAddChild={onAddChild}
                onCopyPath={onCopyPath}
                copiedPath={copiedPath}
                errorMap={errorMap}
              />
            ))}

          {((currentType === 'object' && Object.keys(value || {}).length === 0) ||
            (currentType === 'array' && value.length === 0)) && (
            <div className="py-1 text-xs text-stone-400 italic">Vacío</div>
          )}
        </div>
      )}
    </div>
  );
}
