import React, { useState } from 'react';
import { X, Copy, Check, Code, Box, Layers, ArrowRight } from 'lucide-react';

interface EmbedCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function EmbedCodeModal({ isOpen, onClose }: EmbedCodeModalProps) {
  const [activeTab, setActiveTab] = useState<'react' | 'props' | 'odoo'>('react');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const reactSnippet = `import React, { useState } from 'react';
import { OmniFlowDataEditor } from './components/OmniFlowDataEditor';

export function MyOmniFlowModule() {
  const [pipelineData, setPipelineData] = useState({
    name: 'Sync Odoo Leads',
    steps: []
  });

  return (
    <div className="p-6 bg-stone-100 min-h-screen">
      <h2 className="text-xl font-bold mb-4">Módulo de Automatización OmniFlow</h2>
      
      {/* Componente Standalone acoplado */}
      <OmniFlowDataEditor
        initialData={pipelineData}
        onChange={(updated) => {
          setPipelineData(updated);
          // Opcional: sincronizar con el backend de OmniFlow
        }}
        defaultView="table" // 'table' | 'tree' | 'raw'
        schema="res.partner" // Validador de esquema Odoo
      />
    </div>
  );
}`;

  const odooSnippet = `/**
 * Wrapper de integración para OmniFlow Core & Odoo OWL Microfrontend
 */
import { Component, xml, useState } from "@odoo/owl";
import { OmniFlowDataEditor } from "omniflow-data-editor";

export class OmniFlowEditorWidget extends Component {
    static template = xml\`
        <div class="o_omniflow_editor_container">
            <div t-ref="root" />
        </div>
    \`;

    setup() {
        this.state = useState({ data: this.props.record.data[this.props.name] });
    }

    // Monta el componente React en el contenedor OWL
    mounted() {
        // Renderizado via createRoot con OmniFlowDataEditor
    }
}`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-stone-200 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-stone-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Box className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-stone-900">
                Acoplamiento al Core de OmniFlow
              </h3>
              <p className="text-xs text-stone-500">
                Uso como componente standalone o embebido en módulos Odoo / OmniFlow
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-stone-200 px-6 bg-white gap-4 text-xs font-medium">
          <button
            onClick={() => setActiveTab('react')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'react'
                ? 'border-indigo-600 text-indigo-600 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            Uso en React / Next.js
          </button>
          <button
            onClick={() => setActiveTab('props')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'props'
                ? 'border-indigo-600 text-indigo-600 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Props API del Módulo
          </button>
          <button
            onClick={() => setActiveTab('odoo')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'odoo'
                ? 'border-indigo-600 text-indigo-600 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            Odoo OWL Integration
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === 'react' && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-stone-500">Ejemplo de integración directa:</span>
                <button
                  onClick={() => handleCopy(reactSnippet)}
                  className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:text-indigo-800"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copiado al portapapeles' : 'Copiar Código'}
                </button>
              </div>
              <pre className="p-4 bg-stone-900 text-emerald-300 font-mono text-xs rounded-xl overflow-x-auto leading-relaxed border border-stone-800">
                {reactSnippet}
              </pre>
            </div>
          )}

          {activeTab === 'props' && (
            <div className="space-y-3 text-xs">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-stone-200 text-stone-600 font-semibold">
                    <th className="py-2 pr-3">Prop</th>
                    <th className="py-2 px-3">Tipo</th>
                    <th className="py-2 px-3">Default</th>
                    <th className="py-2 pl-3">Descripción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-stone-700">
                  <tr>
                    <td className="py-2.5 pr-3 font-mono font-bold text-indigo-600">initialData</td>
                    <td className="py-2.5 px-3 font-mono text-stone-500">any</td>
                    <td className="py-2.5 px-3 font-mono">[]</td>
                    <td className="py-2.5 pl-3">Estado inicial de datos en formato JSON nativo.</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 pr-3 font-mono font-bold text-indigo-600">onChange</td>
                    <td className="py-2.5 px-3 font-mono text-stone-500">(data: any) =&gt; void</td>
                    <td className="py-2.5 px-3 font-mono">undefined</td>
                    <td className="py-2.5 pl-3">Callback emitido ante cualquier cambio en tabla, árbol o código.</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 pr-3 font-mono font-bold text-indigo-600">defaultView</td>
                    <td className="py-2.5 px-3 font-mono text-stone-500">'table' | 'tree' | 'raw'</td>
                    <td className="py-2.5 px-3 font-mono">'table'</td>
                    <td className="py-2.5 pl-3">Vista visual activa inicial.</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 pr-3 font-mono font-bold text-indigo-600">schema</td>
                    <td className="py-2.5 px-3 font-mono text-stone-500">string</td>
                    <td className="py-2.5 px-3 font-mono">''</td>
                    <td className="py-2.5 pl-3">ID de modelo Odoo ('res.partner', 'product.template', etc.).</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'odoo' && (
            <div>
              <p className="text-xs text-stone-600 mb-3 leading-relaxed">
                Para incrustar este editor dentro del backend de Odoo (v16, v17 o v18) usando OWL o vistas de formulario personalizadas:
              </p>
              <pre className="p-4 bg-stone-900 text-emerald-300 font-mono text-xs rounded-xl overflow-x-auto leading-relaxed border border-stone-800">
                {odooSnippet}
              </pre>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-stone-50 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
}
