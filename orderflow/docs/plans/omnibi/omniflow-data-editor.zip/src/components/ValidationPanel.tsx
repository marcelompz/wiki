import React from 'react';
import { ShieldCheck, AlertCircle, AlertTriangle, CheckCircle2, ChevronRight, Info } from 'lucide-react';
import { ValidationError } from '../types';
import { ODOO_SCHEMAS } from '../utils/schemaValidator';

interface ValidationPanelProps {
  selectedSchemaId: string;
  onSelectSchema: (id: string) => void;
  errors: ValidationError[];
}

export function ValidationPanel({ selectedSchemaId, onSelectSchema, errors }: ValidationPanelProps) {
  const currentSchema = ODOO_SCHEMAS[selectedSchemaId];
  const errorCount = errors.filter((e) => e.severity === 'error').length;
  const warningCount = errors.filter((e) => e.severity === 'warning').length;

  return (
    <div id="validation-panel" className="bg-white rounded-xl border border-stone-200 p-4 shadow-xs">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-stone-900">Validación Temprana Odoo / OmniFlow</h4>
            <p className="text-xs text-stone-500">Verifica restricciones de modelos antes de exportar o cargar</p>
          </div>
        </div>

        {/* Schema Dropdown */}
        <div className="flex items-center gap-2">
          <label htmlFor="schema-select" className="text-xs font-medium text-stone-600">
            Modelo:
          </label>
          <select
            id="schema-select"
            value={selectedSchemaId}
            onChange={(e) => onSelectSchema(e.target.value)}
            className="text-xs font-medium bg-stone-50 hover:bg-stone-100 border border-stone-300 rounded-lg px-2.5 py-1.5 text-stone-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 cursor-pointer"
          >
            <option value="">Sin Esquema (Modo Libre)</option>
            {Object.values(ODOO_SCHEMAS).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Schema Details and Status */}
      {selectedSchemaId && currentSchema && (
        <div className="mt-3 pt-3 border-t border-stone-100">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-stone-700 font-mono">
                {currentSchema.odooModel}
              </span>
              <span className="text-xs text-stone-400">&bull;</span>
              <span className="text-xs text-stone-500">{currentSchema.description}</span>
            </div>

            {/* Status Pills */}
            <div className="flex items-center gap-2">
              {errors.length === 0 ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Conforme con {currentSchema.odooModel}
                </span>
              ) : (
                <div className="flex items-center gap-1.5">
                  {errorCount > 0 && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-rose-100 text-rose-800">
                      <AlertCircle className="w-3 h-3" />
                      {errorCount} {errorCount === 1 ? 'Error' : 'Errores'}
                    </span>
                  )}
                  {warningCount > 0 && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                      <AlertTriangle className="w-3 h-3" />
                      {warningCount} {warningCount === 1 ? 'Aviso' : 'Avisos'}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Validation Issue list */}
          {errors.length > 0 && (
            <div className="mt-3 space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {errors.map((err, idx) => (
                <div
                  key={idx}
                  className={`flex items-start gap-2 p-2 rounded-lg text-xs leading-relaxed ${
                    err.severity === 'error'
                      ? 'bg-rose-50/80 text-rose-900 border border-rose-100'
                      : 'bg-amber-50/80 text-amber-900 border border-amber-100'
                  }`}
                >
                  {err.severity === 'error' ? (
                    <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <span className="font-mono font-semibold px-1 py-0.5 bg-white/80 rounded mr-1.5 border border-stone-200/60">
                      {err.path}
                    </span>
                    <span>{err.message}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {!selectedSchemaId && (
        <div className="flex items-center gap-2 p-2.5 rounded-lg bg-stone-50 border border-stone-200/70 text-xs text-stone-600">
          <Info className="w-4 h-4 text-stone-400 flex-shrink-0" />
          <span>
            Selecciona un modelo (ej. <strong>res.partner</strong> para Contactos Odoo o <strong>product.template</strong>) para auditar tipos, requerimientos y campos en vivo sin tocar el servidor.
          </span>
        </div>
      )}
    </div>
  );
}
