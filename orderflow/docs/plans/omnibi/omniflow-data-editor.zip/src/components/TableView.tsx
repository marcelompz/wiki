import React, { useState, useMemo } from 'react';
import {
  Plus,
  Trash2,
  Copy,
  Search,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Columns,
  Check,
  X,
  AlertCircle,
  HelpCircle,
  FileSpreadsheet
} from 'lucide-react';
import { ValidationError } from '../types';

interface TableViewProps {
  data: any;
  onChange: (newData: any) => void;
  validationErrors: ValidationError[];
  onSwitchToTree?: () => void;
}

export function TableView({ data, onChange, validationErrors, onSwitchToTree }: TableViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [editingCell, setEditingCell] = useState<{ rowIdx: number; colKey: string } | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [newColName, setNewColName] = useState('');
  const [showAddColModal, setShowAddColModal] = useState(false);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);

  // Check if data is tabular (array of objects)
  const isArray = Array.isArray(data);
  const isTabular = isArray && data.length > 0 && typeof data[0] === 'object' && data[0] !== null;

  // Extract columns
  const columns = useMemo(() => {
    if (!isArray || data.length === 0) return [];
    const keys = new Set<string>();
    data.forEach((row: any) => {
      if (row && typeof row === 'object') {
        Object.keys(row).forEach((k) => keys.add(k));
      }
    });
    return Array.from(keys);
  }, [data, isArray]);

  // Filter and Sort rows
  const processedRows = useMemo(() => {
    if (!isTabular) return [];

    let rows = data.map((item: any, originalIndex: number) => ({
      ...item,
      __originalIndex: originalIndex,
    }));

    // Search filter
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      rows = rows.filter((row: any) => {
        return columns.some((col) => {
          const val = row[col];
          if (val === null || val === undefined) return false;
          return String(val).toLowerCase().includes(q);
        });
      });
    }

    // Sort
    if (sortColumn) {
      rows.sort((a: any, b: any) => {
        const valA = a[sortColumn];
        const valB = b[sortColumn];

        if (valA === undefined || valA === null) return sortDirection === 'asc' ? 1 : -1;
        if (valB === undefined || valB === null) return sortDirection === 'asc' ? -1 : 1;

        if (typeof valA === 'number' && typeof valB === 'number') {
          return sortDirection === 'asc' ? valA - valB : valB - valA;
        }

        const strA = String(valA).toLowerCase();
        const strB = String(valB).toLowerCase();
        return sortDirection === 'asc' ? strA.localeCompare(strB) : strB.localeCompare(strA);
      });
    }

    return rows;
  }, [data, isTabular, searchTerm, columns, sortColumn, sortDirection]);

  // Validation map: row index + field name -> error
  const errorMap = useMemo(() => {
    const map = new Map<string, ValidationError>();
    validationErrors.forEach((err) => {
      if (err.row !== undefined && err.field) {
        map.set(`${err.row}:${err.field}`, err);
      }
    });
    return map;
  }, [validationErrors]);

  // Handle cell edit commit
  const handleStartEdit = (rowIdx: number, colKey: string, currentVal: any) => {
    setEditingCell({ rowIdx, colKey });
    setEditValue(currentVal === null || currentVal === undefined ? '' : String(currentVal));
  };

  const handleSaveEdit = () => {
    if (!editingCell) return;
    const { rowIdx, colKey } = editingCell;
    const newData = [...data];
    const currentRow = { ...newData[rowIdx] };

    // Infer type if existing is boolean or number
    const existingVal = currentRow[colKey];
    let parsedVal: any = editValue;

    if (typeof existingVal === 'number' || (!isNaN(Number(editValue)) && editValue.trim() !== '')) {
      parsedVal = editValue.trim() === '' ? '' : Number(editValue);
    } else if (typeof existingVal === 'boolean' || editValue === 'true' || editValue === 'false') {
      parsedVal = editValue === 'true';
    }

    currentRow[colKey] = parsedVal;
    newData[rowIdx] = currentRow;
    onChange(newData);
    setEditingCell(null);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSaveEdit();
    } else if (e.key === 'Escape') {
      setEditingCell(null);
    }
  };

  // Add row
  const handleAddRow = () => {
    const newRow: Record<string, any> = {};
    columns.forEach((col) => {
      newRow[col] = '';
    });
    // If no columns yet, add default name
    if (columns.length === 0) {
      newRow['name'] = 'Nuevo Registro';
    }
    onChange([...(Array.isArray(data) ? data : []), newRow]);
  };

  // Delete row
  const handleDeleteRow = (index: number) => {
    if (!Array.isArray(data)) return;
    const newData = data.filter((_, idx) => idx !== index);
    onChange(newData);
    setSelectedRows((prev) => prev.filter((i) => i !== index));
  };

  // Duplicate row
  const handleDuplicateRow = (index: number) => {
    if (!Array.isArray(data)) return;
    const rowToCopy = { ...data[index] };
    if (rowToCopy.name && typeof rowToCopy.name === 'string') {
      rowToCopy.name = `${rowToCopy.name} (Copia)`;
    }
    const newData = [...data];
    newData.splice(index + 1, 0, rowToCopy);
    onChange(newData);
  };

  // Add column
  const handleAddColumn = () => {
    const colName = newColName.trim();
    if (!colName) return;
    if (columns.includes(colName)) {
      alert(`La columna "${colName}" ya existe.`);
      return;
    }

    const newData = (Array.isArray(data) ? data : [{}]).map((row: any) => ({
      ...row,
      [colName]: '',
    }));
    onChange(newData);
    setNewColName('');
    setShowAddColModal(false);
  };

  // Delete column
  const handleDeleteColumn = (colName: string) => {
    if (!window.confirm(`¿Eliminar la columna "${colName}" de todos los registros?`)) return;
    const newData = (Array.isArray(data) ? data : []).map((row: any) => {
      const copy = { ...row };
      delete copy[colName];
      return copy;
    });
    onChange(newData);
  };

  // Sort toggle
  const handleSort = (col: string) => {
    if (sortColumn === col) {
      if (sortDirection === 'asc') setSortDirection('desc');
      else {
        setSortColumn(null);
        setSortDirection('asc');
      }
    } else {
      setSortColumn(col);
      setSortDirection('asc');
    }
  };

  // Non-tabular fallback banner
  if (!isTabular) {
    return (
      <div id="table-view-fallback" className="flex flex-col items-center justify-center p-12 text-center bg-stone-50/50 rounded-xl border border-stone-200">
        <div className="w-14 h-14 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mb-4">
          <FileSpreadsheet className="w-7 h-7" />
        </div>
        <h3 className="text-lg font-semibold text-stone-900 mb-2">
          Estructura Jerárquica / No Tabular Detectada
        </h3>
        <p className="text-stone-600 text-sm max-w-md mb-6 leading-relaxed">
          Los datos actuales contienen un objeto JSON anidado o un tipo complejo.
          La vista de hoja de cálculo requiere una lista de registros. Te sugerimos usar la
          <strong> Vista de Árbol / Formulario</strong> para editar este contenido sin perder la estructura.
        </p>
        <div className="flex gap-3">
          {onSwitchToTree && (
            <button
              id="switch-to-tree-btn"
              onClick={onSwitchToTree}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg shadow-sm transition-colors"
            >
              Cambiar a Vista de Árbol
            </button>
          )}
          <button
            id="convert-object-to-row-btn"
            onClick={() => {
              if (data && typeof data === 'object') {
                onChange([data]);
              } else {
                onChange([{ item: data }]);
              }
            }}
            className="px-4 py-2 bg-white hover:bg-stone-100 text-stone-700 text-sm font-medium rounded-lg border border-stone-300 transition-colors"
          >
            Envolver en Fila Tabular
          </button>
        </div>
      </div>
    );
  }

  return (
    <div id="table-view-container" className="flex flex-col h-full bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
      {/* Top Toolbar */}
      <div id="table-toolbar" className="flex flex-wrap items-center justify-between gap-3 p-3.5 border-b border-stone-200 bg-stone-50/70">
        {/* Left: Search & Filter */}
        <div className="flex items-center gap-2 flex-1 min-w-[240px] max-w-md">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="table-search-input"
              type="text"
              placeholder="Buscar en celdas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-8 py-1.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          <button
            id="add-row-btn"
            onClick={handleAddRow}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            Añadir Registro
          </button>
          <button
            id="add-col-btn"
            onClick={() => setShowAddColModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-700 bg-white hover:bg-stone-100 border border-stone-300 rounded-lg transition-colors"
          >
            <Columns className="w-3.5 h-3.5" />
            Añadir Columna
          </button>
        </div>
      </div>

      {/* Grid Canvas */}
      <div className="overflow-auto flex-1 min-h-[400px]">
        <table id="omniflow-data-table" className="w-full border-collapse text-left text-sm">
          <thead>
            <tr className="bg-stone-100/80 border-b border-stone-200 text-xs font-semibold text-stone-600 uppercase tracking-wider sticky top-0 z-10">
              <th className="w-12 px-3 py-2.5 text-center border-r border-stone-200 bg-stone-100/90">#</th>
              {columns.map((col) => {
                const isSorted = sortColumn === col;
                return (
                  <th
                    key={col}
                    className="px-3.5 py-2.5 border-r border-stone-200 group relative hover:bg-stone-200/60 select-none whitespace-nowrap"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <button
                        onClick={() => handleSort(col)}
                        className="flex items-center gap-1.5 font-semibold text-stone-700 hover:text-indigo-600 text-left"
                      >
                        <span>{col}</span>
                        {isSorted ? (
                          sortDirection === 'asc' ? (
                            <ArrowUp className="w-3.5 h-3.5 text-indigo-600" />
                          ) : (
                            <ArrowDown className="w-3.5 h-3.5 text-indigo-600" />
                          )
                        ) : (
                          <ArrowUpDown className="w-3 h-3 text-stone-400 opacity-0 group-hover:opacity-100" />
                        )}
                      </button>

                      {columns.length > 1 && (
                        <button
                          onClick={() => handleDeleteColumn(col)}
                          title={`Eliminar columna ${col}`}
                          className="opacity-0 group-hover:opacity-100 p-0.5 text-stone-400 hover:text-rose-600 transition-opacity"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </th>
                );
              })}
              <th className="w-24 px-3 py-2.5 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-200 font-normal text-stone-800">
            {processedRows.length === 0 ? (
              <tr>
                <td colSpan={columns.length + 2} className="px-6 py-12 text-center text-stone-500">
                  {searchTerm ? 'No hay registros que coincidan con la búsqueda.' : 'No hay datos en la tabla.'}
                </td>
              </tr>
            ) : (
              processedRows.map((row: any) => {
                const originalIndex = row.__originalIndex;
                const hasRowError = validationErrors.some((e) => e.row === originalIndex);

                return (
                  <tr
                    key={originalIndex}
                    className={`hover:bg-indigo-50/30 transition-colors ${
                      hasRowError ? 'bg-rose-50/30' : ''
                    }`}
                  >
                    <td className="px-3 py-2 text-center text-xs font-mono text-stone-400 border-r border-stone-200 select-none">
                      {originalIndex + 1}
                    </td>

                    {columns.map((col) => {
                      const cellVal = row[col];
                      const isEditing = editingCell?.rowIdx === originalIndex && editingCell?.colKey === col;
                      const cellError = errorMap.get(`${originalIndex}:${col}`);

                      return (
                        <td
                          key={col}
                          onDoubleClick={() => handleStartEdit(originalIndex, col, cellVal)}
                          className={`px-3 py-2 border-r border-stone-200 cursor-text relative ${
                            cellError ? 'bg-rose-100/50' : ''
                          }`}
                        >
                          {isEditing ? (
                            <div className="flex items-center gap-1">
                              <input
                                autoFocus
                                type="text"
                                value={editValue}
                                onChange={(e) => setEditValue(e.target.value)}
                                onKeyDown={handleKeyDown}
                                onBlur={handleSaveEdit}
                                className="w-full px-2 py-0.5 text-sm bg-white border border-indigo-500 rounded ring-2 ring-indigo-500/20 focus:outline-none"
                              />
                              <button
                                onMouseDown={handleSaveEdit}
                                className="p-1 text-emerald-600 hover:text-emerald-700"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <div
                              onClick={() => handleStartEdit(originalIndex, col, cellVal)}
                              className="min-h-[22px] flex items-center justify-between group"
                            >
                              <span className="truncate">
                                {cellVal === null || cellVal === undefined ? (
                                  <span className="text-stone-300 italic text-xs">null</span>
                                ) : typeof cellVal === 'boolean' ? (
                                  <span
                                    className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium ${
                                      cellVal
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : 'bg-stone-100 text-stone-600'
                                    }`}
                                  >
                                    {cellVal ? 'true' : 'false'}
                                  </span>
                                ) : typeof cellVal === 'object' ? (
                                  <span className="text-indigo-600 font-mono text-xs">
                                    {JSON.stringify(cellVal)}
                                  </span>
                                ) : (
                                  String(cellVal)
                                )}
                              </span>

                              {cellError && (
                                <span
                                  title={cellError.message}
                                  className="text-rose-600 ml-1 flex-shrink-0"
                                >
                                  <AlertCircle className="w-3.5 h-3.5" />
                                </span>
                              )}
                            </div>
                          )}
                        </td>
                      );
                    })}

                    {/* Actions */}
                    <td className="px-2 py-2 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1 opacity-80 hover:opacity-100">
                        <button
                          onClick={() => handleDuplicateRow(originalIndex)}
                          title="Duplicar registro"
                          className="p-1 text-stone-400 hover:text-indigo-600 hover:bg-stone-100 rounded"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteRow(originalIndex)}
                          title="Eliminar registro"
                          className="p-1 text-stone-400 hover:text-rose-600 hover:bg-stone-100 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Footer info */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-stone-50 border-t border-stone-200 text-xs text-stone-500">
        <div>
          Mostrando <strong>{processedRows.length}</strong> de <strong>{data.length}</strong> registros &bull;{' '}
          <strong>{columns.length}</strong> columnas
        </div>
        <div className="flex items-center gap-1.5 text-stone-400">
          <HelpCircle className="w-3.5 h-3.5" />
          <span>Haz doble clic en una celda para editar en caliente</span>
        </div>
      </div>

      {/* Modal: Add Column */}
      {showAddColModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-5 border border-stone-200">
            <h4 className="text-base font-semibold text-stone-900 mb-1">Añadir Nueva Columna</h4>
            <p className="text-xs text-stone-500 mb-4">
              Ingresa el identificador técnico del campo (por ejemplo: <code className="bg-stone-100 px-1 py-0.5 rounded">vat</code> o <code className="bg-stone-100 px-1 py-0.5 rounded">phone</code>).
            </p>
            <input
              autoFocus
              type="text"
              placeholder="Nombre del campo"
              value={newColName}
              onChange={(e) => setNewColName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddColumn();
                if (e.key === 'Escape') setShowAddColModal(false);
              }}
              className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowAddColModal(false)}
                className="px-3 py-1.5 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Cancelar
              </button>
              <button
                onClick={handleAddColumn}
                className="px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
              >
                Crear Columna
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
